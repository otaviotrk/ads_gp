package com.example.provamobile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.provamobile.databinding.FragmentAlunoBinding;

public class AlunoFragment extends Fragment {

    FragmentAlunoBinding binding;

    public AlunoFragment() {
        super(R.layout.fragment_aluno);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAlunoBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Button btnAluno = binding.btnAluno;
        btnAluno.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.blankFragment, null)
        );

    }
}