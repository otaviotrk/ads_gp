package com.example.provamobile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.provamobile.databinding.FragmentCadastroBinding;

public class CadastroFragment extends Fragment {

    FragmentCadastroBinding binding;
    DBSingleton dbsingleton;

    public CadastroFragment() {
        super(R.layout.fragment_cadastro);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCadastroBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbsingleton = DBSingleton.getInstance(this.getContext());
        PessoaDao pessoaDao = dbsingleton.db.pessoaDao();

        Button btnCadastarPessoa = binding.btnCadastrarPessoa;
        btnCadastarPessoa.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 Pessoa novapessoa = new Pessoa(binding.editCadastroNome.getText().toString(), binding.editCadastroFuncao.getText().toString());
                 pessoaDao.InserirAluno(novapessoa);
                 System.out.println("Cadastro concluido");
             }
         }
        );

        binding.btnVoltar.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.blankFragment, null)
        );
    }

}