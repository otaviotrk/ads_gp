package com.example.provamobile;

import android.content.Context;

import androidx.room.Room;

public class DBSingleton {
    static DBSingleton object;
    public AppDatabase db;

    public static DBSingleton getInstance(Context context) {
        if (object == null) {
            object = new DBSingleton();
            object.db = Room.databaseBuilder(context, AppDatabase.class, "database-name").allowMainThreadQueries().build();
        }
        return object;
    }

    private DBSingleton () {

    }

}
