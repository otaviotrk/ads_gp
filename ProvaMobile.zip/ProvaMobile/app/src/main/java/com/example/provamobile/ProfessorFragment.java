package com.example.provamobile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.provamobile.databinding.FragmentProfessorBinding;

import java.util.ArrayList;
import java.util.List;

public class ProfessorFragment extends Fragment {

    FragmentProfessorBinding binding;
    DBSingleton dbSingleton;

    public ProfessorFragment() {
        super(R.layout.fragment_professor);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfessorBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbSingleton = DBSingleton.getInstance(this.getContext());
        PessoaDao pessoaDao = dbSingleton.db.pessoaDao();
        List<Pessoa> pessoas = pessoaDao.listarpessoas();
        ArrayList<Pessoa> listapessoas = (ArrayList<Pessoa>) pessoas;
        ArrayList<String> pessoasnalista = new ArrayList<String>();
        for (Pessoa pessoa: listapessoas) {
            if (pessoa.funcao.equals("Aluno")) {
                System.out.print("Nome: ");
                System.out.println(pessoa.nome);
                pessoasnalista.add(pessoa.nome);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getContext(), android.R.layout.simple_list_item_1, pessoasnalista);
        ListView listView = binding.listAlunos;
        listView.setAdapter(adapter);

        Button btnExcluir = binding.btnExcluir;
        btnExcluir.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 pessoaDao.DeletarAlunos();
             }
         }
        );
    }
}