package com.example.provamobile;

import android.view.View;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface PessoaDao {
    @Query("SELECT * FROM Pessoa")
    List<Pessoa> listarpessoas();

    @Query("DELETE FROM Pessoa")
    void DeletarAlunos();

    @Delete
    void DeletarUmAluno(Pessoa pessoa);

    @Insert
    void InserirAluno(Pessoa pessoa);
}
