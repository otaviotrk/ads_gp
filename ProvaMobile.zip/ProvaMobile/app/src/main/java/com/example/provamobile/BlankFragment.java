package com.example.provamobile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.provamobile.databinding.FragmentBlankBinding;

import java.util.Locale;

public class BlankFragment extends Fragment {

    FragmentBlankBinding binding;

    public BlankFragment() {
        super(R.layout.fragment_blank);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentBlankBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Button btnEntrar = binding.btnEntrar;
        Button btnCadastar = binding.btnCadastrar;

        btnEntrar.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 EditText textocampo = binding.editTextAluno;
                 String textocaracter = textocampo.getText().toString();
                 if (textocaracter.equals("Professor")) {
                     btnEntrar.setText("Confirma");
                     irparaoprofessor();
                 }
                 else if (textocaracter.equals("Aluno")) {
                     btnEntrar.setText("Confirma");
                     System.out.println(textocaracter);
                     irparaoaluno();
                 }
             }
         }
        );

        btnCadastar.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.cadastroFragment, null)
        );

    }

    public void irparaoprofessor() {
        binding.btnEntrar.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.professorFragment, null)
        );
    }

    public void irparaoaluno() {
        binding.btnEntrar.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.alunoFragment, null)
        );
    }

}