package com.example.provamobile;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Pessoa {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String nome;
    public String funcao;
    public Pessoa(String nomePessoa, String funcaoPessoa) {
        this.nome = nomePessoa;
        this.funcao = funcaoPessoa;
    }

    public Pessoa() {

    }
}
